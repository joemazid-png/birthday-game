'use client'

import { useState, useEffect, useRef } from 'react'
import { Cake, PartyPopper } from 'lucide-react'
import confetti from 'canvas-confetti'

type Stage = 'welcome' | 'game' | 'celebration'

interface CakeSlice {
  id: number
  found: boolean
  top: string
  left: string
}

export default function BirthdayApp() {
  const [stage, setStage] = useState<Stage>('welcome')
  const [foundCount, setFoundCount] = useState(0)
  const [cakeSlices, setCakeSlices] = useState<CakeSlice[]>([])
  const iframeRef = useRef<HTMLIFrameElement | null>(null)

  // Initialize cake slices
  useEffect(() => {
    const slices: CakeSlice[] = [
      { id: 1, found: false, top: '15%', left: '10%' },
      { id: 2, found: false, top: '45%', left: '85%' },
      { id: 3, found: false, top: '70%', left: '20%' },
      { id: 4, found: false, top: '25%', left: '75%' },
      { id: 5, found: false, top: '60%', left: '50%' },
    ]
    setCakeSlices(slices)
  }, [])

  const handleStartGame = () => {
    setStage('game')
  }

  const handleFindSlice = (id: number) => {
    setCakeSlices((prev) =>
      prev.map((slice) => (slice.id === id ? { ...slice, found: true } : slice))
    )
    setFoundCount((prev) => prev + 1)
  }

  // Auto-transition to celebration when all slices found
  useEffect(() => {
    if (foundCount === 5 && stage === 'game') {
      setTimeout(() => {
        setStage('celebration')
        // Trigger confetti
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          gravity: 0.8,
        })
      }, 500)
    }
  }, [foundCount, stage])

  return (
    <div className="min-h-screen overflow-hidden bg-gradient-to-br from-pink-100 via-purple-100 to-blue-100">
      {/* YouTube birthday song - hidden and auto-plays */}
      <iframe
        ref={iframeRef}
        width="0"
        height="0"
        src="https://www.youtube.com/embed/WMPHqFeeCKw?autoplay=1"
        allow="autoplay"
        style={{ display: 'none' }}
      />

      {/* Stage 1: Welcome Screen */}
      {stage === 'welcome' && (
        <div className="flex min-h-screen flex-col items-center justify-center gap-8 p-4">
          <div className="flex flex-col items-center gap-6">
            <div className="animate-bounce">
              <PartyPopper className="h-24 w-24 text-pink-500" />
            </div>
            <h1 className="text-center text-6xl font-bold md:text-7xl">
              <span className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
                Feliz Aniversário!
              </span>
            </h1>
            <p className="text-center text-2xl font-semibold text-purple-600 md:text-3xl">
              🎉 Happy Birthday! 🎉
            </p>
          </div>

          <button
            onClick={handleStartGame}
            className="group relative inline-block overflow-hidden rounded-full bg-gradient-to-r from-pink-500 to-purple-500 p-0.5 transition-all duration-300 hover:shadow-2xl hover:shadow-pink-500/50"
          >
            <div className="relative rounded-full bg-white px-8 py-4 text-center font-bold text-purple-600 transition-all duration-300 group-hover:bg-transparent group-hover:text-white md:px-12 md:py-6 md:text-xl">
              <span className="animate-pulse">Clique para começar</span>
            </div>
          </button>

          <div className="flex justify-center gap-4 text-4xl">
            <span className="animate-bounce" style={{ animationDelay: '0s' }}>
              🎂
            </span>
            <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>
              🎈
            </span>
            <span className="animate-bounce" style={{ animationDelay: '0.4s' }}>
              🎁
            </span>
          </div>
        </div>
      )}

      {/* Stage 2: The Hidden Cake Game */}
      {stage === 'game' && (
        <div className="relative min-h-screen p-4 md:p-8">
          {/* Counter */}
          <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50">
            <div className="rounded-full bg-white/90 backdrop-blur px-6 py-3 shadow-lg">
              <p className="text-center font-bold text-lg md:text-xl">
                <span className="bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
                  Fatias de bolo encontradas: {foundCount}/5
                </span>
              </p>
            </div>
          </div>

          {/* Game content */}
          <div className="flex min-h-screen items-center justify-center">
            <div className="relative w-full max-w-4xl">
              {/* Characters and cake stand */}
              <div className="flex items-center justify-center gap-4 md:gap-12">
                {/* Youssef with empty cake stand */}
                <div className="flex flex-col items-center gap-2">
                  <div className="text-5xl md:text-7xl">😊</div>
                  <div className="text-2xl md:text-3xl">Youssef</div>
                  <div className="text-6xl">🎂</div>
                </div>

                {/* Birthday boy */}
                <div className="flex flex-col items-center gap-2">
                  <div className="text-5xl md:text-7xl">😄</div>
                  <div className="text-2xl md:text-3xl">You!</div>
                  <div className="text-6xl">🎉</div>
                </div>
              </div>

              {/* Hidden cake slices */}
              {cakeSlices.map(
                (slice) =>
                  !slice.found && (
                    <button
                      key={slice.id}
                      onClick={() => handleFindSlice(slice.id)}
                      className="group absolute z-10 transition-transform duration-200 hover:scale-125 cursor-pointer"
                      style={{ top: slice.top, left: slice.left }}
                      aria-label={`Cake slice ${slice.id}`}
                    >
                      <span className="block text-4xl md:text-5xl drop-shadow-lg group-hover:drop-shadow-xl">
                        🍰
                      </span>
                    </button>
                  )
              )}
            </div>
          </div>

          {/* Floating decorations */}
          <div className="pointer-events-none fixed inset-0 overflow-hidden">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className="absolute animate-float text-4xl md:text-5xl"
                style={{
                  top: `${Math.random() * 50}%`,
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${i * 0.5}s`,
                  opacity: 0.3,
                }}
              >
                🎈
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stage 3: Celebration & The Letter */}
      {stage === 'celebration' && (
        <div className="min-h-screen overflow-y-auto bg-gradient-to-br from-yellow-100 via-pink-100 to-purple-100 p-4 md:p-8">
          {/* Celebration Scene */}
          <div className="flex min-h-[50vh] items-center justify-center">
            <div className="flex flex-col items-center gap-8 md:gap-12">
              {/* Happy Youssef giving cake */}
              <div className="flex items-center justify-center gap-4 md:gap-8">
                <div className="flex flex-col items-center gap-2">
                  <div className="text-6xl md:text-8xl animate-bounce">😊</div>
                  <div className="text-xl md:text-2xl font-bold">Youssef</div>
                </div>

                {/* Big beautiful cake */}
                <div className="animate-bounce text-7xl md:text-9xl" style={{ animationDelay: '0.2s' }}>
                  🎂
                </div>

                {/* Happy birthday boy */}
                <div className="flex flex-col items-center gap-2">
                  <div className="text-6xl md:text-8xl animate-bounce" style={{ animationDelay: '0.4s' }}>
                    🎉
                  </div>
                  <div className="text-xl md:text-2xl font-bold">You!</div>
                </div>
              </div>

              {/* Celebration text */}
              <div className="text-center">
                <p className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
                  🎊 FELIZ ANIVERSÁRIO! 🎊
                </p>
              </div>
            </div>
          </div>

          {/* The Letter */}
          <div className="mx-auto max-w-2xl py-8">
            <div className="rounded-2xl bg-white/95 backdrop-blur p-6 md:p-10 shadow-2xl border-2 border-purple-200">
              <div className="mb-6 text-center">
                <Cake className="mx-auto h-12 w-12 text-pink-500 mb-2" />
                <h2 className="text-2xl md:text-3xl font-bold text-purple-600">
                  Uma Mensagem Especial
                </h2>
              </div>

              <div className="prose prose-sm md:prose-base max-w-none">
                <p className="text-lg md:text-xl leading-relaxed text-gray-700 mb-4">
                  Desejo a você um ano muito bom e doce. Você é uma das melhores pessoas que já conheci na minha vida. De verdade, apesar da distância, você é uma das melhores pessoas que já conheci.
                </p>
                <p className="text-lg md:text-xl leading-relaxed text-gray-700 mb-4">
                  Desejo a você um ano novo muito feliz, cheio de doçura e uma vida longa. Que você seja muito feliz na sua vida, e que este novo ano seja repleto de conquistas e sucesso.
                </p>
                <p className="text-lg md:text-xl leading-relaxed text-gray-700 font-semibold">
                  Com carinho,{' '}
                  <span className="text-purple-600">seu amigo egípcio, Youssef.</span>
                </p>
              </div>

              <div className="mt-8 flex justify-center gap-3 text-3xl">
                <span className="animate-pulse">💙</span>
                <span className="animate-pulse" style={{ animationDelay: '0.2s' }}>
                  🎂
                </span>
                <span className="animate-pulse" style={{ animationDelay: '0.4s' }}>
                  💙
                </span>
              </div>
            </div>
          </div>

          {/* Floating confetti elements */}
          <div className="pointer-events-none fixed inset-0 overflow-hidden">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="absolute animate-float text-3xl md:text-4xl"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${i * 0.3}s`,
                  opacity: Math.random() * 0.5 + 0.2,
                }}
              >
                {['🎉', '🎊', '🎈', '🎁'][i % 4]}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Global styles for animations */}
      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) rotate(0deg);
            opacity: 0;
          }
          10% {
            opacity: 0.8;
          }
          90% {
            opacity: 0.8;
          }
          100% {
            transform: translateY(-100vh) rotate(360deg);
            opacity: 0;
          }
        }

        .animate-float {
          animation: float 8s infinite linear;
        }
      `}</style>
    </div>
  )
}
